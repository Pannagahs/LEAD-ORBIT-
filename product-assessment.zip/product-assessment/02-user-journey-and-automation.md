# LeadOrbit - Journey Notes (Working Draft)

## Real Workflow I Optimized For
1. Lead comes in from source.
2. System assigns priority/owner.
3. Rep sees lead in list and takes first action.
4. Rep opens details only when deeper context is needed.
5. Rep logs outcome and next follow-up.
6. Manager tracks stuck leads and SLA delays.
7. Manager uses dashboard for weekly decisions.

## UX Decisions I Took Intentionally
1. Listing is action-first, not data-heavy.
2. Details screen is for context and qualification depth.
3. Manager board supports bulk movement and re-assignment.
4. Dashboard is concise: enough to decide, not overloaded.

## Status Flow Used
- New
- Contacted
- Qualified
- Test Drive Scheduled
- Negotiation
- Won
- Not Interested
- Lost

## KPI Set For Manager View
1. Leads by source
2. First-contact SLA percentage
3. Qualification percentage
4. Test drive booking percentage
5. Win percentage
6. Average closure time
7. Aging leads by owner

## Which Screen To Upload As Main
Use: screen-1-lead-listing.svg

Why I chose this one:
- It immediately shows business value.
- It demonstrates both volume handling and workflow speed.
- It includes automation cues (SLA risk, quick action, assignment).
