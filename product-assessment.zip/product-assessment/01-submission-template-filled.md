# DeltaX Product Specialist Assignment

## Product Name
LeadOrbit

## How I Understood The Problem
HSR Motors is already getting enough leads. The real issue is handling them fast and consistently.

Today they are using spreadsheets, so a lot depends on manual follow-up and individual discipline. That usually leads to 3 problems:
- Leads are not contacted on time.
- Reps do not always know what to do next.
- Managers cannot quickly see where leads are getting stuck.

So my goal was simple: make day-to-day lead handling easier for the sales team, while giving managers a clear view of performance.

## User Types And What They Need
1. Sales Team
- Open lead list and act immediately.
- See status, priority, and next step without digging.
- Update lead outcome quickly after each call.

2. Business Manager
- See overall numbers quickly (volume, conversion, aging).
- Spot bottlenecks by source and by rep.
- Intervene early when SLAs are at risk.

## Proposed Product
I designed a desktop-first internal app called LeadOrbit with 4 core screens:
1. Lead Listing
2. Lead Details
3. Lead Management
4. Dashboard

This is not a public website. It is an operations tool for the internal team.

## Why These 4 Screens
1. Lead Listing
- This is where reps spend most of their time.
- It is optimized for quick scanning and quick actions.

2. Lead Details
- This is for qualification depth: notes, timeline, customer intent, and next best action.

3. Lead Management
- This is a manager/review screen with board-style movement and bulk actions.

4. Dashboard
- This is for daily and weekly performance review.

## Practical Automation I Added
I focused on useful automation that reduces manual work, not flashy features.

1. Lead scoring
- Gives a quick quality signal using source + recency + profile completeness.

2. Suggested next action
- Recommends next step based on current stage and time since last touch.

3. SLA risk alerts
- Highlights leads that may be missed soon.

4. Duplicate checks
- Flags repeat entries using phone/email match confidence.

5. Auto-assignment
- Routes leads based on city, workload, and source.

6. Follow-up triggers
- When status changes, the system can auto-create next task/reminder.

## End-To-End Flow
1. Lead enters from ad platform/website/offline source.
2. System checks duplicates and assigns owner.
3. Sales rep makes first contact and updates status.
4. System suggests next step and due time.
5. Manager tracks movement and stuck leads from Lead Management.
6. Dashboard reflects conversion and team performance in near real time.

## Screens Included In Submission
- Screen 1: Lead Listing (recommended main upload)
- Screen 2: Lead Details
- Screen 3: Lead Management
- Screen 4: Dashboard

## Why This Approach Works For A Product Specialist Role
- It is user-goal driven, not feature-driven.
- It maps directly to daily workflows of both personas.
- It includes measurable outcomes: faster first contact, lower lead leakage, better conversion visibility.
